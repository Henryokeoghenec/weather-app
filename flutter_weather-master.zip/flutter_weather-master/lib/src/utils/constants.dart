class CONSTANTS{
  static const SHARED_PREF_KEY_THEME = "theme_code";
  static const SHARED_PREF_KEY_TEMPERATURE_UNIT = "temp_unit";
}